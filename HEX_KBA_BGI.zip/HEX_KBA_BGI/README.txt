Créateurs : 
- Barré-Guétrot Ilan
- Briot--Amadieu Kellyan

Liste des fonctionnalités :
- Chat entre joueur
- Système de nom (entrée de Pseudo pour jouer)
- Système permettant de changer la couleur d'un joueur (Localement)
- Une zone de texte expliquant comment jouer
- Un status de Spectateur avec une fonctionnalité permettant de naviguer dans l'historique de la partie
- Si un joueur quitte la partie, un autre peut prendre sa place
- Jeu de base (HEX) fonctionnel
- Variable dans clien_socket.io.html permettant de choisir la taille de la table de jeu (La taille doit être strictement supérieur à 1)

Depot GIT :
- https://github.com/kekeamd/HEX_GAME